const { sequelize } = require ("../config/database");

module.exports = (sequelize, DataTypes)=>
{
    var Empregados = sequelize.define('empregados',

        {
            id:{
                type: DataTypes.BIGINT(20),
                primaryKey: true,
                autoIncrement: true
            },
            nome: {
                type: DataTypes.STRING
            },
            salarioBruto:{
                type: DataTypes.DECIMAL(12,2)
            },
            departamento:{
                type: DataTypes.INTEGER
            }

        },{
            timestamps:false
        }
   )

   return Empregados

}


