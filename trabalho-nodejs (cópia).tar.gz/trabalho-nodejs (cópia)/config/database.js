const Sequelize = require("sequelize");
sequelize = new Sequelize('trabalho3bi','root','mysqluser',
{
    host:'localhost',
    dialect:'mysql'
})

module.exports = {
    Sequelize,
    sequelize
}